<?= $this->extend('admin/base'); ?>

<?= $this->section('content'); ?>

<div class="card">
  <div class="card-header">
    Blank
  </div>
  <div class="card-body">
    <p>Blank</p>
  </div>
</div>

<?= $this->endSection(); ?>